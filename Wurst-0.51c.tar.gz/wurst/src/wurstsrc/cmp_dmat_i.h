/*
 * $Id: cmp_dmat_i.h,v 1.1 2007/09/28 16:57:03 mmundry Exp $
 */

#ifndef CMP_DMAT_I_H
#define CMP_DMAT_I_H

struct coord;
int dme_thresh (float *frac, struct coord *c1, struct coord *c2, float thresh);


#endif /* CMP_DMAT_H */
