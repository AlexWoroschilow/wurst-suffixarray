/*
 * 27 Oct 2005
 * rcsid = $Id: solv_data.h,v 1.1 2007/09/28 16:57:11 mmundry Exp $
 */
#ifndef SOLV_DATA_H
#define SOLV_DATA_H

struct coord;
int get_nbor (struct coord *c);

#endif /* SOLV_DATA_H */
