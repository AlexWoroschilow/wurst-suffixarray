/*
 * 21 Sep 2001
 * A long and complicated file.
 * rscsid = "$Id: yesno.h,v 1.1 2007/09/28 16:57:10 mmundry Exp $"
 */
#ifndef YESNO_H
#define YESNO_H

enum yes_no {
    NO  = 0,
    YES = 1
};

#endif  /* YESNO_H */
