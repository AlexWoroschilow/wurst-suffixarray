/* 
 * $Id: coordinfo_i.h,v 1.1 2007/09/28 16:57:06 mmundry Exp $
 */
#ifndef COORDINFO_I_H
#define COORDINFO_I_H
char *         coord_get_sec_s (struct coord *c);
#endif
