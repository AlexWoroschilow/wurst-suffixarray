/*
 * 30 May 2002
 * $Id: binver.h,v 1.1 2007/09/28 16:57:11 mmundry Exp $
 */
#ifndef BINVER_H
#define BINVER_H

const char * bin_version (void);
#endif /* BINVER_H */
