#ifndef __GSL_PERMUTE_H__
#define __GSL_PERMUTE_H__

#include "gsl_permute_double.h"


#endif				/* __GSL_PERMUTE_H__ */
