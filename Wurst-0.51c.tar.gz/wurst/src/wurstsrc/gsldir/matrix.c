#include "gsl_errno.h"
#include "gsl_matrix_double.h"

#define BASE_DOUBLE
#include "templates_on.h"
#include "matrix_source.c"
#include "templates_off.h"
#undef  BASE_DOUBLE
