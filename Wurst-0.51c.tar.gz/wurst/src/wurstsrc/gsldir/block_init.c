#include <stdlib.h>
#include "gsl_block.h"

#define BASE_DOUBLE
#include "templates_on.h"
#include "block_init_source.c"
#include "templates_off.h"
#undef  BASE_DOUBLE
