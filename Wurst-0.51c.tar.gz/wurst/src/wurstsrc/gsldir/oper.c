#include <stdlib.h>
#include "gsl_vector_double.h"

#define BASE_DOUBLE
#include "templates_on.h"
#include "oper_source.c"
#include "templates_off.h"
#undef  BASE_DOUBLE
