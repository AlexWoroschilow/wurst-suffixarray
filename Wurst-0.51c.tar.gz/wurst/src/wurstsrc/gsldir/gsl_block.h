#ifndef __GSL_BLOCK_H__
#define __GSL_BLOCK_H__

#include "gsl_block_double.h"


#endif				/* __GSL_BLOCK_H__ */
