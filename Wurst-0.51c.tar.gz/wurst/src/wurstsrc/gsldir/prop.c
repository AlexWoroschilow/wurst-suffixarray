#include "gsl_vector_double.h"
#include "gsl_errno.h"

#define BASE_DOUBLE
#include "templates_on.h"
#include "prop_source.c"
#include "templates_off.h"
#undef  BASE_DOUBLE
