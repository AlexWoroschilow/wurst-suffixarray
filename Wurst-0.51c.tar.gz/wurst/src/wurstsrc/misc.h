/*
 * 25 February 2002
 * rcsid = $Id: misc.h,v 1.1 2007/09/28 16:57:06 mmundry Exp $
 */
#ifndef MISC_H
#define MISC_H

char *get_nline (FILE *fp, char *lbuf, int *nr_line, const size_t maxbuf);

#endif  /* MISC_H */
