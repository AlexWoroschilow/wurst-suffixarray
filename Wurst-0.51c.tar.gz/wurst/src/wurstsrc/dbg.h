/*
 * 9 april 2001
 * rcsid = $Id: dbg.h,v 1.1 2007/09/28 16:57:10 mmundry Exp $
 */
#ifndef DBG_H
#define DBG_H

void breaker ( void );
#endif /* DBG_H */
